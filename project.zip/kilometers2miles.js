// input
let kilometers = 56;

//processing

//output

console.log(`${kilometers} is ?? miles`)